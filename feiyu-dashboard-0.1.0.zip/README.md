# 鱼鱼仪表盘 · AI 酱插件

把「鱼鱼家」的器官 / 插件 / 记忆状况显示在 AI 酱里。**只读**，不改任何服务。

## 依赖

本机要有鱼鱼状态桥在跑：

```bash
python D:\FeiyuHome\02_工具与环境\鱼鱼状态桥\status_bridge.py serve
```

它监听 `http://127.0.0.1:8765/status`，只读采集六器官（主脑/嘴/QQ/声音/眼/身体）、AstrBot 插件加载状态、记忆库各层条数、NapCat 最后一条消息时间。

## 做什么

- 命令 `feiyu-dashboard.status`：拉一次状态，返回摘要
- 面板 `feiyu-dashboard`：展示器官、插件、记忆明细

## 许可

MIT
